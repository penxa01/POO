class usuarioprueba:
    unusuario=None
    def __init__(self):
        self.unusuario=None
    def delusuario(self):
        self.unusuario=None

       
    def addusuario(self,usuario):
        self.unusuario=usuario
class recetaprueba:
    id=None
    def __init__(self):
        self.id=None
    def addreceta(self,id):
        self.id=id
    def delreceta(self):
        self.id=None
   